import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmailComponent } from './email/email.component';
import { FullNameComponent } from './full-name/full-name.component';
import { ActionsComponent } from './actions/actions.component';
import { IndexComponent } from './index/index.component';
import { IdComponent } from './id/id.component';
import { CreateNewUserComponent } from './create-new-user/create-new-user.component';

@NgModule({
  declarations: [
    AppComponent,
    EmailComponent,
    FullNameComponent,
    ActionsComponent,
    IndexComponent,
    IdComponent,
    CreateNewUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
